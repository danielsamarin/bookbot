import { resolve } from "node:path";
import { defineConfig } from "electron-vite";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  main: {
    build: {
      rollupOptions: {
        input: {
          index: resolve("src/main/index.ts"),
          "extension-host": resolve("src/main/extension-host.ts")
        },
        external: ["esbuild"],
        output: {
          entryFileNames: "[name].js"
        }
      }
    },
    resolve: {
      alias: {
        "@shared": resolve("src/shared")
      }
    }
  },
  preload: {
    build: {
      lib: {
        entry: resolve("src/main/preload.ts"),
        formats: ["cjs"],
        fileName: () => "preload.js"
      }
    },
    resolve: {
      alias: {
        "@shared": resolve("src/shared")
      }
    }
  },
  renderer: {
    resolve: {
      alias: {
        "@": resolve("src/renderer/src"),
        "@components": resolve("src/renderer/src/components"),
        "@shared": resolve("src/shared"),
        "@styles": resolve("src/renderer/src/Styles")
      }
    },
    plugins: [react(), tailwindcss()]
  }
});
