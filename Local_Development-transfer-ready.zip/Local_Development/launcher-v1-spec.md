# Raycast-Style Work Launcher v1 Spec

## 1. Product Summary

Build a Windows-only, local-first desktop application inspired by Raycast that helps a developer automate repetitive daily work tasks through:

- A floating command bar launched by a global hotkey
- Keyboard-first commands with mouse support
- Modal-based interaction flows
- A local extension system with hot reload
- A deterministic automation model for v1

The first intended user is a single developer working on a locked-down company machine, with possible future sharing inside a developer team.

## 2. v1 Goals

### In Scope

- Floating launcher window
- Global hotkey to open the launcher
- Command search with built-in and extension commands shown together
- Modal UI flows for commands that need input
- Settings UI
- Toast notifications for success
- Prompt-based failure handling
- Local markdown note creation
- Folder structure creation from settings-defined templates
- Local extension loader
- Hello World example extension
- Extension developer mode with reload and logs
- Per-extension permissions with local trust state

### Out of Scope

- AI features
- Cloud sync
- Marketplace or public extension publishing
- Team permissions and admin controls
- Clipboard history in v1
- Run history UI in v1
- Scheduled automations in v1
- Secret storage and third-party auth in v1
- Bitbucket clone and network backup in milestone 1

## 3. Core UX

### Primary Interaction Model

1. User presses a global hotkey.
2. Launcher opens as a floating command bar centered on screen.
3. User types to search commands.
4. Selecting a command either:
   - executes immediately, or
   - opens a modal for required inputs.
5. The app shows a toast on success.
6. On failure, the app shows a prompt with the error and available next actions.

### UX Rules

- Keyboard-first, but all controls must be clickable.
- Built-in commands and extension commands must look identical in search results.
- UI beyond the launcher should open in lightweight modals, not a full dashboard.
- Settings should be available through a launcher command and a dedicated modal view.
- Debug logs are developer-facing and do not need a polished end-user history UI yet.

## 4. Initial Built-In Commands

### 4.1 Create Note

Purpose:
Create a markdown note in a user-defined notes directory.

Flow:
1. User runs `Create Note`.
2. Modal prompts for note title.
3. App generates a filename from the title.
4. App writes a markdown file into the configured notes directory.
5. App optionally inserts starter content.
6. Success toast confirms creation.

Settings:
- `notesRootPath`
- `noteFilenameFormat` (optional later)
- `noteTemplate` (optional later)

Initial behavior:
- Save as `.md`
- Use a simple slugged title as filename
- Default contents can be a top-level heading with the title

### 4.2 Create Folder Structure

Purpose:
Create a project folder under a configured root path and create configured subfolders inside it.

Flow:
1. User runs `Create Folder Structure`.
2. Modal prompts for project/folder name.
3. App creates `<root>/<projectName>/`.
4. App creates each configured subfolder inside the new project folder.
5. Success toast confirms creation.

Settings:
- `folderTemplateRootPath`
- `folderTemplateSubfolders` as ordered list of relative folder paths

Example:
- Root path: `C:\Development\Projects`
- Project name input: `Client Portal`
- Subfolders:
  - `docs`
  - `src`
  - `assets`

Result:
- `C:\Development\Projects\Client Portal\docs`
- `C:\Development\Projects\Client Portal\src`
- `C:\Development\Projects\Client Portal\assets`

### 4.3 Settings

Purpose:
Manage app-level configuration.

Required settings for milestone 1:
- Global hotkey
- Notes root path
- Folder template root path
- Folder template subfolders
- Developer mode on/off
- Code-based workflow mode on/off placeholder

## 5. Platform and Tech Stack

### Recommended Stack

- Desktop shell: Electron
- UI: React + TypeScript
- Styling: CSS Modules or Tailwind plus a small design token layer
- State: Zustand or simple React state for milestone 1
- Validation: Zod
- Local database: SQLite
- Human-editable config: JSON files
- Packaging later: electron-builder

### Why This Stack

- Electron is well suited for Windows desktop integration, global shortcuts, notifications, and local file operations.
- React + TypeScript provides fast iteration and a strong extension SDK story.
- SQLite gives a stable foundation for future command indexing, run history, extension caching, and settings migrations.
- JSON settings files keep core configuration inspectable and editable on a locked-down machine.

## 6. Architecture

### Process Model

#### Electron Main Process

Responsibilities:
- App lifecycle
- Global hotkey registration
- Window management
- Native notifications/toasts
- Extension discovery
- Permission enforcement
- IPC broker between renderer and extension host
- Script execution broker for PowerShell/Python actions

#### Electron Renderer Process

Responsibilities:
- Launcher UI
- Search UI
- Modal UI
- Settings UI
- Developer mode UI

Renderer restrictions:
- No direct shell execution
- No direct unrestricted filesystem mutation
- Must go through typed IPC calls

#### Extension Host Process

Use a separate Node.js child process for extension runtime in v1.

Responsibilities:
- Load trusted extensions
- Validate manifests
- Register commands
- Execute TypeScript extension handlers
- Request privileged actions from the main process

Rationale:
- Safer than executing extension code in the renderer
- Easier to reload during development
- Clean boundary for permissions and future sandboxing

### Storage Model

#### JSON Files

Use JSON for:
- User settings
- Extension trust decisions
- Developer preferences

Suggested location:
- `%APPDATA%\\WorkLauncher\\settings.json`
- `%APPDATA%\\WorkLauncher\\trusted-extensions.json`

#### SQLite

Use SQLite for:
- Indexed command catalog cache
- Extension metadata cache
- Future run history
- Future searchable state

Suggested location:
- `%APPDATA%\\WorkLauncher\\app.db`

## 7. Proposed Project Structure

```text
work-launcher/
  package.json
  tsconfig.json
  electron.vite.config.ts
  src/
    main/
      index.ts
      windows/
        launcherWindow.ts
      shortcuts/
        globalHotkey.ts
      ipc/
        channels.ts
        handlers/
          commands.ts
          settings.ts
          extensions.ts
      services/
        notifications.ts
        settingsService.ts
        commandRegistry.ts
        extensionManager.ts
        permissionService.ts
        scriptRunner.ts
        fileActions.ts
      extensions/
        extensionHostBridge.ts
        manifestSchema.ts
    renderer/
      app/
        App.tsx
        routes.ts
      components/
        Launcher/
        Modal/
        CommandList/
        Toast/
        Settings/
      features/
        commands/
        settings/
        developer/
      lib/
        ipc.ts
        types.ts
        search.ts
      styles/
        tokens.css
        globals.css
    shared/
      commands.ts
      settings.ts
      extensions.ts
  extensions/
    hello-world/
      manifest.json
      src/
        index.ts
  docs/
    extension-sdk.md
```

## 8. Command Model

All commands, built-in or extension-provided, should normalize to one internal shape:

```ts
type CommandDefinition = {
  id: string;
  title: string;
  subtitle?: string;
  source: "builtin" | "extension";
  extensionId?: string;
  mode: "run" | "view";
  keywords?: string[];
  permissions?: PermissionKey[];
};
```

Behavior:
- `run` executes immediately.
- `view` opens a modal or custom command view.

This ensures built-ins and extensions are rendered consistently in the launcher.

## 9. Extension System

### v1 Requirements

- Extensions live in a local `extensions/` folder
- Each extension contains a manifest and source code
- Commands contributed by extensions appear in launcher results
- Extensions can define settings
- Extensions can open modals
- Extensions can trigger toast notifications
- Extensions can request approved actions like file operations or script execution
- Dev mode supports reload and validation errors

### Extension Package Layout

```text
extensions/
  hello-world/
    manifest.json
    package.json
    src/
      index.ts
      commands/
        hello.ts
```

### Manifest Schema

```ts
type PermissionKey =
  | "filesystem"
  | "shell"
  | "network"
  | "clipboard";

type ExtensionSetting =
  | {
      key: string;
      title: string;
      type: "text";
      defaultValue?: string;
    }
  | {
      key: string;
      title: string;
      type: "boolean";
      defaultValue?: boolean;
    }
  | {
      key: string;
      title: string;
      type: "folder";
      defaultValue?: string;
    };

type ExtensionCommand = {
  id: string;
  title: string;
  description?: string;
  entry: string;
  mode: "run" | "view";
  keywords?: string[];
};

type ExtensionManifest = {
  schemaVersion: 1;
  id: string;
  name: string;
  version: string;
  description?: string;
  author?: string;
  permissions: PermissionKey[];
  commands: ExtensionCommand[];
  settings?: ExtensionSetting[];
};
```

### Example Manifest

```json
{
  "schemaVersion": 1,
  "id": "hello-world",
  "name": "Hello World",
  "version": "0.1.0",
  "description": "Example extension for local development",
  "permissions": ["filesystem"],
  "commands": [
    {
      "id": "hello-world.say-hello",
      "title": "Say Hello",
      "description": "Open a sample modal and show a toast",
      "entry": "./src/commands/hello.ts",
      "mode": "view",
      "keywords": ["example", "demo"]
    }
  ],
  "settings": [
    {
      "key": "greetingTarget",
      "title": "Greeting Target",
      "type": "text",
      "defaultValue": "World"
    }
  ]
}
```

### Permission Model

Permissions are declared in the manifest and enforced by the main process.

Rules:
- Local extensions can be trusted manually.
- Trusting an extension does not automatically grant all dangerous actions.
- Sensitive permissions like `shell` and `network` should be toggleable per extension.
- Extensions request actions through typed APIs, not raw Node access in the renderer.

### Script Execution Model

PowerShell and Python should be exposed as wrapped extension actions, not arbitrary UI-side process spawning.

Examples:
- `runPowerShell(scriptPath, args)`
- `runPython(scriptPath, args)`

Guardrails:
- Only callable if the extension has `shell` permission
- Only callable from trusted extensions
- Executed by the main process or a dedicated broker service
- Logged in developer mode

## 10. Settings Model

### App Settings Shape

```ts
type AppSettings = {
  globalHotkey: string;
  notesRootPath: string;
  folderTemplateRootPath: string;
  folderTemplateSubfolders: string[];
  developerMode: boolean;
  enableCodeWorkflows: boolean;
};
```

Suggested defaults:
- `globalHotkey`: `Alt+Space`
- `developerMode`: `true` in development
- `enableCodeWorkflows`: `false`

### Extension Settings

Extension settings should merge:
- manifest defaults
- user overrides stored in app config

Suggested storage shape:

```json
{
  "extensions": {
    "hello-world": {
      "greetingTarget": "World"
    }
  }
}
```

## 11. Error Handling and Notifications

### Success

- Show a toast notification
- Keep it lightweight and dismissible

### Failure

- Show a modal or prompt with:
  - error summary
  - details
  - retry/cancel choices when relevant

### Developer Logging

Developer mode should show:
- extension load failures
- manifest validation errors
- IPC/action errors
- script execution output and failures

No polished user-facing history screen is required in milestone 1.

## 12. Hello World Extension Requirements

The starter extension must prove all core extension concepts:

- Contributes a command to launcher search
- Opens a modal input form
- Reads one extension setting
- Shows a toast notification
- Exercises at least one typed API call from extension to host

Example behavior:
1. User runs `Say Hello`.
2. Modal asks for a name.
3. Extension reads `greetingTarget` default when input is blank.
4. Extension returns `Hello, <name>` in a simple modal or toast.

## 13. Milestone 1 Delivery Plan

### Milestone 1 Objective

Ship the smallest credible local launcher with:
- floating command bar
- settings UI
- create note command
- create folder structure command
- extension loader
- hello world extension

### Task Breakdown

#### A. App Shell

- Initialize Electron + React + TypeScript project
- Create launcher window with hidden-by-default behavior
- Register global hotkey
- Add command search input and result list
- Add modal system
- Add toast system

#### B. Shared Contracts

- Define shared types for commands, settings, and extension manifests
- Implement Zod schemas for validation
- Create typed IPC channel wrappers

#### C. Settings

- Build settings service with JSON persistence
- Build settings modal UI
- Add path pickers for note root and folder template root
- Add editable list UI for subfolders

#### D. Built-In Commands

- Implement `Create Note`
- Implement `Create Folder Structure`
- Add file/path validation and user-friendly failure prompts

#### E. Extension Runtime

- Implement extension directory discovery
- Parse and validate manifests
- Load trusted extensions into extension host
- Register extension commands into the shared command registry
- Add file watching and hot reload in development

#### F. Developer Experience

- Add developer mode toggle
- Add extension validation errors panel or modal
- Add reload extensions command
- Log extension host output

#### G. Hello World Example

- Create sample extension
- Demonstrate modal input
- Demonstrate settings
- Demonstrate toast output

### Milestone 1 Exit Criteria

- Launcher opens with global hotkey
- Built-in commands are searchable and usable
- Settings persist across restarts
- Extension command appears alongside built-ins
- Editing the example extension reloads it in development
- Permission declarations are parsed and surfaced

## 14. Milestone 2 Candidates

After milestone 1, the next best additions are:

- Bitbucket clone from pasted URL
- Manual backup to network share
- Clipboard history
- Command usage history
- Multi-step workflows
- Optional code-based workflow authoring

## 15. Recommended Build Order

Build in this order:

1. App shell and launcher interaction
2. Shared command registry
3. Settings persistence and UI
4. Create Note
5. Create Folder Structure
6. Extension manifest schema and loader
7. Hello World extension
8. Hot reload and developer tooling

## 16. Implementation Notes from Raycast Reference

Useful ideas to borrow from Raycast:

- Commands should be the fundamental unit of contribution.
- Extension commands should surface directly in root search.
- Preferences/settings should be declared and validated.
- Developer workflow should be fast and reload-friendly.
- Extension code should run behind a runtime boundary rather than directly in the UI layer.

Raycast reference material:
- Manifest: https://developers.raycast.com/information/manifest
- File structure: https://developers.raycast.com/information/file-structure
- Preferences API: https://developers.raycast.com/api-reference/preferences
- CLI and development workflow: https://developers.raycast.com/information/developer-tools/cli
- Security overview: https://developers.raycast.com/information/security

## 17. Recommended Next Step

Start implementation by scaffolding the Electron app shell and the shared command/settings contracts. Once the launcher window, settings persistence, and command registry exist, the first two built-in commands and the extension loader can be added without reworking the foundation.
