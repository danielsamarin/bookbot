import { z } from "zod";
import { clipboardTransformOptions } from "./clipboard";

export const permissionSchema = z.enum(["filesystem", "shell", "network", "clipboard"]);

export const networkShareSchema = z.object({
  label: z.string(),
  path: z.string()
});

export const savedWindowsPathSchema = z.object({
  label: z.string(),
  path: z.string()
});

export const appSettingsSchema = z.object({
  globalHotkey: z.string().min(1),
  autoMinimizeAfterAction: z.boolean(),
  notesRootPath: z.string(),
  folderTemplateRootPath: z.string(),
  folderTemplateSubfolders: z.array(z.string()),
  networkShares: z.array(networkShareSchema),
  savedWindowsPaths: z.array(savedWindowsPathSchema),
  developerMode: z.boolean(),
  enableCodeWorkflows: z.boolean()
});

export const extensionSettingSchema = z.discriminatedUnion("type", [
  z.object({
    key: z.string().min(1),
    title: z.string().min(1),
    type: z.literal("text"),
    defaultValue: z.string().optional()
  }),
  z.object({
    key: z.string().min(1),
    title: z.string().min(1),
    type: z.literal("boolean"),
    defaultValue: z.boolean().optional()
  }),
  z.object({
    key: z.string().min(1),
    title: z.string().min(1),
    type: z.literal("folder"),
    defaultValue: z.string().optional()
  })
]);

export const extensionCommandSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  description: z.string().optional(),
  entry: z.string().min(1),
  mode: z.enum(["run", "view"]),
  keywords: z.array(z.string()).optional(),
  promptLabel: z.string().optional(),
  promptPlaceholder: z.string().optional()
});

export const extensionManifestSchema = z.object({
  schemaVersion: z.literal(1),
  id: z.string().min(1),
  name: z.string().min(1),
  version: z.string().min(1),
  description: z.string().optional(),
  author: z.string().optional(),
  permissions: z.array(permissionSchema),
  commands: z.array(extensionCommandSchema),
  settings: z.array(extensionSettingSchema).optional()
});

export const commandDefinitionSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  subtitle: z.string().optional(),
  iconDataUrl: z.string().optional(),
  resultType: z.enum(["command", "folder", "share", "saved-path", "note"]).optional(),
  targetPath: z.string().optional(),
  completionPath: z.string().optional(),
  source: z.enum(["builtin", "extension"]),
  extensionId: z.string().optional(),
  mode: z.enum(["run", "view"]),
  viewId: z
    .enum([
      "create-note",
      "create-folder",
      "settings",
      "extension-prompt",
      "browse-notes",
      "clipboard-actions",
      "clipboard-history"
    ])
    .optional(),
  keywords: z.array(z.string()).optional(),
  permissions: z.array(permissionSchema).optional(),
  promptLabel: z.string().optional(),
  promptPlaceholder: z.string().optional()
});

export const commandExecutionPayloadSchema = z.record(
  z.union([z.string(), z.boolean(), z.array(z.string()), z.undefined()])
);

export const commandExecutionResultSchema = z.object({
  ok: z.boolean(),
  title: z.string().optional(),
  message: z.string(),
  detail: z.string().optional(),
  data: z.record(z.unknown()).optional()
});

export const noteSummarySchema = z.object({
  path: z.string(),
  name: z.string(),
  title: z.string(),
  modifiedAt: z.number()
});

export const noteFileSchema = noteSummarySchema.extend({
  content: z.string()
});

export const clipboardHistoryEntrySchema = z.object({
  id: z.string(),
  text: z.string(),
  copiedAt: z.number()
});

export const clipboardTransformIdSchema = z.enum(
  clipboardTransformOptions.map((option) => option.id) as [
    (typeof clipboardTransformOptions)[number]["id"],
    ...Array<(typeof clipboardTransformOptions)[number]["id"]>
  ]
);

export const folderSuggestionSchema = z.object({
  name: z.string(),
  path: z.string(),
  completionPath: z.string()
});

export const folderAutocompleteResultSchema = z.object({
  exactPath: z.string().nullable(),
  suggestions: z.array(folderSuggestionSchema)
});

export type PermissionKey = z.infer<typeof permissionSchema>;
export type AppSettings = z.infer<typeof appSettingsSchema>;
export type ExtensionManifest = z.infer<typeof extensionManifestSchema>;
export type CommandDefinition = z.infer<typeof commandDefinitionSchema>;
export type CommandExecutionPayload = z.infer<typeof commandExecutionPayloadSchema>;
export type CommandExecutionResult = z.infer<typeof commandExecutionResultSchema>;
export type NoteSummary = z.infer<typeof noteSummarySchema>;
export type NoteFile = z.infer<typeof noteFileSchema>;
export type ClipboardHistoryEntry = z.infer<typeof clipboardHistoryEntrySchema>;
export type ClipboardTransformId = z.infer<typeof clipboardTransformIdSchema>;
export type FolderSuggestion = z.infer<typeof folderSuggestionSchema>;
export type FolderAutocompleteResult = z.infer<typeof folderAutocompleteResultSchema>;
export type NetworkShare = z.infer<typeof networkShareSchema>;
export type SavedWindowsPath = z.infer<typeof savedWindowsPathSchema>;

export type ExtensionSettingsMap = Record<string, Record<string, unknown>>;

export type TrustRecord = {
  trusted: boolean;
  grantedPermissions: PermissionKey[];
};

export type TrustState = Record<string, TrustRecord>;

export type DevState = {
  loadedExtensions: Array<{
    id: string;
    name: string;
    commandCount: number;
    permissions: PermissionKey[];
  }>;
  diagnostics: string[];
};

export type ExtensionHostCommandRegistration = {
  commandId: string;
  entryPath: string;
};

export type ExtensionHostRegistration = {
  extensionId: string;
  extensionName: string;
  extensionPath: string;
  commands: ExtensionHostCommandRegistration[];
};

export type ExtensionExecutionContext = {
  extensionId: string;
  commandId: string;
  payload: CommandExecutionPayload;
  settings: Record<string, unknown>;
};

export type ExtensionHostIncomingMessage =
  | {
      type: "bootstrap";
      extensions: ExtensionHostRegistration[];
    }
  | {
      type: "execute";
      requestId: string;
      extensionId: string;
      commandId: string;
      payload: CommandExecutionPayload;
      settings: Record<string, unknown>;
    };

export type ExtensionHostOutgoingMessage =
  | {
      type: "ready";
    }
  | {
      type: "bootstrap-complete";
      diagnostics: string[];
    }
  | {
      type: "execute-result";
      requestId: string;
      result: CommandExecutionResult;
    }
  | {
      type: "execute-error";
      requestId: string;
      error: string;
      detail?: string;
    };

export const defaultAppSettings: AppSettings = {
  globalHotkey: "Control+Alt+Space",
  autoMinimizeAfterAction: false,
  notesRootPath: "",
  folderTemplateRootPath: "",
  folderTemplateSubfolders: ["docs", "src", "assets"],
  networkShares: [],
  savedWindowsPaths: [],
  developerMode: true,
  enableCodeWorkflows: false
};
