export const clipboardTransformOptions = [
  {
    id: "trim-whitespace",
    title: "Trim Whitespace",
    description: "Remove leading and trailing whitespace from the current text."
  },
  {
    id: "uppercase",
    title: "Uppercase",
    description: "Convert every letter to uppercase."
  },
  {
    id: "lowercase",
    title: "Lowercase",
    description: "Convert every letter to lowercase."
  },
  {
    id: "slugify",
    title: "Slugify",
    description: "Turn the text into a URL-friendly slug."
  },
  {
    id: "json-pretty",
    title: "Prettify JSON",
    description: "Format valid JSON with indentation for easier reading."
  },
  {
    id: "json-minify",
    title: "Minify JSON",
    description: "Remove extra whitespace from valid JSON."
  }
] as const;

export type ClipboardTransformId = (typeof clipboardTransformOptions)[number]["id"];

const ensureValidJson = (text: string) => {
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("This action needs valid JSON in the clipboard.");
  }
};

export const getClipboardTransformOption = (action: ClipboardTransformId) =>
  clipboardTransformOptions.find((option) => option.id === action);

export const transformClipboardText = (action: ClipboardTransformId, text: string) => {
  switch (action) {
    case "trim-whitespace":
      return text.trim();
    case "uppercase":
      return text.toUpperCase();
    case "lowercase":
      return text.toLowerCase();
    case "slugify":
      return (
        text
          .normalize("NFKD")
          .replace(/[^\w\s-]/g, "")
          .trim()
          .toLowerCase()
          .replace(/[\s_-]+/g, "-")
          .replace(/^-+|-+$/g, "") || "clipboard"
      );
    case "json-pretty":
      return JSON.stringify(ensureValidJson(text), null, 2);
    case "json-minify":
      return JSON.stringify(ensureValidJson(text));
    default: {
      const exhaustiveCheck: never = action;
      return exhaustiveCheck;
    }
  }
};
