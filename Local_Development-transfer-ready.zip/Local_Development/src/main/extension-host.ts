import { build } from "esbuild";
import type {
  CommandExecutionResult,
  ExtensionExecutionContext,
  ExtensionHostIncomingMessage,
  ExtensionHostOutgoingMessage
} from "@shared/contracts";

type ExtensionCommandHandler = (context: ExtensionExecutionContext) => Promise<unknown> | unknown;

const commandHandlers = new Map<string, ExtensionCommandHandler>();

const sendMessage = (message: ExtensionHostOutgoingMessage) => {
  if (typeof process.send === "function") {
    process.send(message);
  }
};

const toDataUrl = (code: string) => `data:text/javascript;base64,${Buffer.from(code).toString("base64")}`;

const resolveHandler = async (entryPath: string): Promise<ExtensionCommandHandler> => {
  const buildResult = await build({
    entryPoints: [entryPath],
    bundle: true,
    platform: "node",
    format: "esm",
    target: ["node20"],
    write: false,
    sourcemap: "inline"
  });

  const output = buildResult.outputFiles?.[0]?.text;
  if (!output) {
    throw new Error(`No build output was generated for ${entryPath}`);
  }

  const module = await import(toDataUrl(output));
  const candidate = module.default ?? module.execute ?? module.command;

  if (typeof candidate === "function") {
    return candidate as ExtensionCommandHandler;
  }

  if (candidate && typeof candidate.execute === "function") {
    return candidate.execute.bind(candidate) as ExtensionCommandHandler;
  }

  throw new Error(`The command module at ${entryPath} must export a function or an object with execute().`);
};

const normalizeResult = (value: unknown): CommandExecutionResult => {
  if (typeof value === "object" && value !== null && "ok" in value) {
    return value as CommandExecutionResult;
  }

  if (typeof value === "string") {
    return {
      ok: true,
      message: value
    };
  }

  if (typeof value === "object" && value !== null) {
    const candidate = value as Partial<CommandExecutionResult>;
    return {
      ok: true,
      title: candidate.title,
      message: candidate.message ?? "Extension command completed.",
      detail: candidate.detail
    };
  }

  return {
    ok: true,
    message: "Extension command completed."
  };
};

const bootstrapExtensions = async (message: Extract<ExtensionHostIncomingMessage, { type: "bootstrap" }>) => {
  commandHandlers.clear();
  const diagnostics: string[] = [];

  for (const extension of message.extensions) {
    for (const command of extension.commands) {
      try {
        const handler = await resolveHandler(command.entryPath);
        commandHandlers.set(command.commandId, handler);
      } catch (error) {
        diagnostics.push(
          `Failed to load ${extension.extensionId}/${command.commandId}: ${error instanceof Error ? error.message : String(error)}`
        );
      }
    }
  }

  sendMessage({
    type: "bootstrap-complete",
    diagnostics
  });
};

const executeCommand = async (message: Extract<ExtensionHostIncomingMessage, { type: "execute" }>) => {
  const handler = commandHandlers.get(message.commandId);

  if (!handler) {
    sendMessage({
      type: "execute-error",
      requestId: message.requestId,
      error: `No extension handler is loaded for ${message.commandId}.`
    });
    return;
  }

  try {
    const result = await handler({
      extensionId: message.extensionId,
      commandId: message.commandId,
      payload: message.payload,
      settings: message.settings
    });

    sendMessage({
      type: "execute-result",
      requestId: message.requestId,
      result: normalizeResult(result)
    });
  } catch (error) {
    sendMessage({
      type: "execute-error",
      requestId: message.requestId,
      error: error instanceof Error ? error.message : String(error)
    });
  }
};

process.on("message", (message: ExtensionHostIncomingMessage) => {
  void (async () => {
    if (message.type === "bootstrap") {
      await bootstrapExtensions(message);
      return;
    }

    if (message.type === "execute") {
      await executeCommand(message);
    }
  })();
});

sendMessage({ type: "ready" });
