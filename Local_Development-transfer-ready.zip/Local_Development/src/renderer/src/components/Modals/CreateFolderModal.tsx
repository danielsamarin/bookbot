import { useState } from "react";
import type { CommandDefinition, CommandExecutionPayload } from "@shared/contracts";

import { Badge } from "@components/UI/Badge";
import { Button } from "@components/UI/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { Field, FieldGroup, FieldLabel } from "@components/UI/Field";
import { Input } from "@components/UI/Input";

interface CreateFolderModalProps {
  command: CommandDefinition;
  isBusy: boolean;
  onCancel: () => void;
  onSubmit: (payload?: CommandExecutionPayload) => void;
  rootPath: string;
  subfolders: string[];
}

export function CreateFolderModal({
  command,
  isBusy,
  onCancel,
  onSubmit,
  rootPath,
  subfolders
}: CreateFolderModalProps) {
  const [projectName, setProjectName] = useState("");

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{command.title}</DialogTitle>
        <DialogDescription>{command.subtitle ?? "Create a project folder and your configured subfolders."}</DialogDescription>
      </DialogHeader>
      <div className="flex flex-col gap-4 px-6 py-1">
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="project-name">Project name</FieldLabel>
            <Input
              autoFocus
              id="project-name"
              onChange={(event) => setProjectName(event.target.value)}
              placeholder="Client Portal"
              value={projectName}
            />
          </Field>
        </FieldGroup>
        <Card className="border-border/60 bg-background/40 shadow-none">
          <CardHeader className="gap-3">
            <CardTitle className="text-sm">Folder template</CardTitle>
            <CardDescription className="break-all">{rootPath || "Set the root path in Settings first."}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            {subfolders.length > 0 ? subfolders.map((subfolder, index) => <Badge key={`${index}-${subfolder}`} variant="subtle">{subfolder}</Badge>) : <span className="text-sm text-muted-foreground">No subfolders configured.</span>}
          </CardContent>
        </Card>
      </div>
      <DialogFooter>
        <Button onClick={onCancel} variant="ghost">
          Cancel
        </Button>
        <Button disabled={isBusy || !projectName.trim()} onClick={() => onSubmit({ projectName })}>
          {isBusy ? "Creating..." : "Create Folders"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
