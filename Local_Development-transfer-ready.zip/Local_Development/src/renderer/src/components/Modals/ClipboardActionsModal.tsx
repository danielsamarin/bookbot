import { useEffect, useMemo, useState } from "react";
import { CopyPlus, RefreshCw } from "lucide-react";
import type { CommandDefinition, CommandExecutionPayload } from "@shared/contracts";
import {
  clipboardTransformOptions,
  type ClipboardTransformId,
  transformClipboardText
} from "@shared/clipboard";

import { Button } from "@components/UI/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { Field, FieldDescription, FieldGroup, FieldLabel } from "@components/UI/Field";
import { Textarea } from "@components/UI/Textarea";
import { getWorkLauncherApi } from "@/Services/LauncherApi";

interface ClipboardActionsModalProps {
  command: CommandDefinition;
  isBusy: boolean;
  onCancel: () => void;
  onSubmit: (payload?: CommandExecutionPayload) => void;
}

const defaultAction: ClipboardTransformId = "trim-whitespace";

const formatCharacterCount = (value: string) =>
  `${value.length.toLocaleString()} character${value.length === 1 ? "" : "s"}`;

export function ClipboardActionsModal({
  command,
  isBusy,
  onCancel,
  onSubmit
}: ClipboardActionsModalProps) {
  const launcherApi = getWorkLauncherApi();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedAction, setSelectedAction] = useState<ClipboardTransformId>(defaultAction);
  const [sourceText, setSourceText] = useState("");

  const loadClipboardText = async () => {
    if (!launcherApi) {
      setError("Restart the Electron app to reload the desktop bridge.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const text = await launcherApi.getClipboardText();
      setSourceText(text);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadClipboardText();
  }, []);

  const preview = useMemo(() => {
    try {
      return {
        value: transformClipboardText(selectedAction, sourceText),
        error: null
      };
    } catch (previewError) {
      return {
        value: "",
        error: previewError instanceof Error ? previewError.message : String(previewError)
      };
    }
  }, [selectedAction, sourceText]);

  return (
    <DialogContent className="flex max-h-[min(85vh,38rem)] flex-col overflow-hidden p-0 md:max-w-[860px]">
      <DialogHeader>
        <DialogTitle>{command.title}</DialogTitle>
        <DialogDescription>
          {command.subtitle ?? "Transform the current clipboard text and copy the result back."}
        </DialogDescription>
      </DialogHeader>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="grid min-h-0 gap-0 lg:grid-cols-[16rem_minmax(0,1fr)]">
          <aside className="border-b border-border bg-muted/20 lg:border-r lg:border-b-0">
            <div className="flex flex-col gap-2 p-4">
              {clipboardTransformOptions.map((option) => (
                <Button
                  key={option.id}
                  className="h-auto items-start justify-start px-3 py-3 text-left"
                  onClick={() => setSelectedAction(option.id)}
                  variant={selectedAction === option.id ? "secondary" : "outline"}
                >
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium">{option.title}</span>
                    <span className="whitespace-normal text-xs text-muted-foreground">
                      {option.description}
                    </span>
                  </div>
                </Button>
              ))}
            </div>
          </aside>
          <main className="grid min-h-0 gap-0 lg:grid-cols-2">
            <section className="flex min-h-0 flex-col border-b border-border lg:border-r lg:border-b-0">
              <div className="flex items-center justify-between gap-3 border-b border-border px-6 py-4">
                <div className="flex flex-col gap-1">
                  <h2 className="text-sm font-medium text-foreground">Clipboard Input</h2>
                  <p className="text-xs text-muted-foreground">
                    Edit the current clipboard text before applying an action.
                  </p>
                </div>
                <Button disabled={isLoading} onClick={() => void loadClipboardText()} variant="outline">
                  <RefreshCw data-icon="inline-start" className={isLoading ? "animate-spin" : undefined} />
                  Refresh
                </Button>
              </div>
              <div className="flex min-h-0 flex-1 flex-col gap-4 px-6 py-5">
                <FieldGroup className="min-h-0 flex-1">
                  <Field className="min-h-0 flex-1">
                    <FieldLabel htmlFor="clipboard-input">Source text</FieldLabel>
                    <Textarea
                      autoFocus
                      className="min-h-[12rem] max-h-[18rem] flex-1 resize-y"
                      id="clipboard-input"
                      onChange={(event) => setSourceText(event.target.value)}
                      placeholder="Clipboard text will appear here"
                      value={sourceText}
                    />
                    <FieldDescription>
                      {error
                        ? error
                        : isLoading
                          ? "Loading clipboard text..."
                          : formatCharacterCount(sourceText)}
                    </FieldDescription>
                  </Field>
                </FieldGroup>
              </div>
            </section>
            <section className="flex min-h-0 flex-col">
              <div className="border-b border-border px-6 py-4">
                <h2 className="text-sm font-medium text-foreground">Preview</h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  This is what will be written back to the clipboard.
                </p>
              </div>
              <div className="flex min-h-0 flex-1 flex-col gap-4 px-6 py-5">
                {preview.error ? (
                  <Card>
                    <CardHeader>
                      <CardTitle>Action needs different input</CardTitle>
                      <CardDescription>{preview.error}</CardDescription>
                    </CardHeader>
                  </Card>
                ) : null}
                <FieldGroup className="min-h-0 flex-1">
                  <Field className="min-h-0 flex-1">
                    <FieldLabel htmlFor="clipboard-preview">Transformed text</FieldLabel>
                    <Textarea
                      className="min-h-[12rem] max-h-[18rem] flex-1 resize-y"
                      id="clipboard-preview"
                      readOnly
                      value={preview.value}
                    />
                    <FieldDescription>{formatCharacterCount(preview.value)}</FieldDescription>
                  </Field>
                </FieldGroup>
                <Card>
                  <CardContent className="flex items-start gap-3 p-4">
                    <CopyPlus data-icon="inline-start" className="mt-0.5 size-4 text-muted-foreground" />
                    <div className="flex flex-col gap-1">
                      <p className="text-sm font-medium text-foreground">
                        {clipboardTransformOptions.find((option) => option.id === selectedAction)?.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        The transformed text replaces your current clipboard contents when you run the action.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </section>
          </main>
        </div>
      </div>
      <DialogFooter>
        <Button onClick={onCancel} variant="ghost">
          Cancel
        </Button>
        <Button
          disabled={isBusy || isLoading || Boolean(preview.error)}
          onClick={() => onSubmit({ action: selectedAction, text: sourceText })}
        >
          {isBusy ? "Updating..." : "Copy Result"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
