import { useEffect, useMemo, useState } from "react";
import type { CommandDefinition, NoteFile, NoteSummary } from "@shared/contracts";
import { FileText, RefreshCw, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@components/UI/Button";
import { Card, CardContent } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { ScrollArea } from "@components/UI/ScrollArea";
import { Textarea } from "@components/UI/Textarea";
import { getWorkLauncherApi } from "@/Services/LauncherApi";

interface ViewNoteModalProps {
  command: CommandDefinition;
  note: NoteSummary;
  onCancel: () => void;
  onRequestDelete: (note: NoteSummary) => void;
}

const formatModifiedAt = (modifiedAt: number) =>
  new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(modifiedAt));

const formatCharacterCount = (value: string) =>
  `${value.length.toLocaleString()} character${value.length === 1 ? "" : "s"}`;

export function ViewNoteModal({ command, note, onCancel, onRequestDelete }: ViewNoteModalProps) {
  const launcherApi = getWorkLauncherApi();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [noteFile, setNoteFile] = useState<NoteFile | null>(null);
  const [draftContent, setDraftContent] = useState("");

  const loadNote = async () => {
    if (!launcherApi) {
      setError("Restart the Electron app to reload the desktop bridge.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const nextNote = await launcherApi.readNote(note.path);
      setNoteFile(nextNote);
      setDraftContent(nextNote.content);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadNote();
  }, [note.path]);

  const isDirty = useMemo(() => draftContent !== (noteFile?.content ?? ""), [draftContent, noteFile]);

  const saveNote = async () => {
    if (!launcherApi || !noteFile || typeof launcherApi.writeNote !== "function") {
      setError("Restart the Electron app to reload the desktop bridge.");
      return;
    }

    setIsSaving(true);
    try {
      const updatedNote = await launcherApi.writeNote(noteFile.path, draftContent);
      setNoteFile(updatedNote);
      setDraftContent(updatedNote.content);
      setError(null);
      toast.success("Note Saved", { description: updatedNote.name });
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : String(saveError));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <DialogContent className="flex max-h-[min(85vh,42rem)] flex-col overflow-hidden p-0 md:max-w-[860px]">
      <DialogHeader>
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl border border-border bg-background/70">
            <FileText data-icon="inline-start" />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <DialogTitle className="truncate">{note.title}</DialogTitle>
            <DialogDescription>
              {command.title} / {formatModifiedAt(noteFile?.modifiedAt ?? note.modifiedAt)}
            </DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <ScrollArea className="min-h-0 flex-1 px-6 py-5">
        <Card className="border-border/60 bg-background/40 shadow-none">
          <CardContent className="p-4">
            <div className="flex flex-col gap-3">
              {error ? <p className="text-sm text-destructive">{error}</p> : null}
              {isLoading ? (
                <p className="text-sm text-muted-foreground">Loading note...</p>
              ) : (
                <Textarea
                  className="min-h-[20rem] resize-y font-[inherit] leading-6"
                  onChange={(event) => setDraftContent(event.target.value)}
                  value={draftContent}
                />
              )}
              <div className="flex items-center justify-between gap-3 text-sm text-muted-foreground">
                <span>{formatCharacterCount(draftContent)}</span>
                <span>{isDirty ? "Unsaved changes" : "Saved"}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </ScrollArea>
      <DialogFooter>
        <Button
          disabled={isLoading || isSaving || !noteFile}
          onClick={() => onRequestDelete(noteFile ?? note)}
          variant="ghost"
        >
          <Trash2 data-icon="inline-start" />
          Delete
        </Button>
        <Button disabled={isLoading} onClick={() => void loadNote()} variant="outline">
          Refresh
        </Button>
        <Button
          disabled={isLoading || isSaving || !isDirty}
          onClick={() => void saveNote()}
          variant="outline"
        >
          <Save data-icon="inline-start" />
          {isSaving ? "Saving..." : "Save"}
        </Button>
        <Button onClick={onCancel}>Close</Button>
      </DialogFooter>
    </DialogContent>
  );
}
