import type { NoteSummary } from "@shared/contracts";
import { AlertTriangle, FileText, Trash2 } from "lucide-react";

import { Button } from "@components/UI/Button";
import { Card, CardContent } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";

interface DeleteNoteConfirmDialogProps {
  isDeleting: boolean;
  note: NoteSummary;
  onCancel: () => void;
  onConfirm: () => void;
}

export function DeleteNoteConfirmDialog({
  isDeleting,
  note,
  onCancel,
  onConfirm
}: DeleteNoteConfirmDialogProps) {
  return (
    <DialogContent className="w-[min(96vw,30rem)]">
      <DialogHeader>
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl border border-destructive/30 bg-destructive/10 text-destructive">
            <AlertTriangle data-icon="inline-start" />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <DialogTitle className="truncate">Delete Note?</DialogTitle>
            <DialogDescription>This action permanently removes the file from your notes directory.</DialogDescription>
          </div>
        </div>
      </DialogHeader>
      <div className="px-6 py-1">
        <Card className="border-destructive/20 bg-background/40 shadow-none">
          <CardContent className="flex items-start gap-3 p-4">
            <div className="flex size-9 shrink-0 items-center justify-center rounded-lg border border-border bg-background/70">
              <FileText data-icon="inline-start" className="size-4" />
            </div>
            <div className="flex min-w-0 flex-1 flex-col gap-1">
              <p className="truncate text-sm font-medium text-foreground">{note.title}</p>
              <p className="truncate text-sm text-muted-foreground">{note.name}</p>
            </div>
          </CardContent>
        </Card>
      </div>
      <DialogFooter>
        <Button disabled={isDeleting} onClick={onCancel} variant="ghost">
          Cancel
        </Button>
        <Button
          className="border-destructive/30 bg-destructive text-destructive-foreground hover:bg-destructive/90"
          disabled={isDeleting}
          onClick={onConfirm}
        >
          <Trash2 data-icon="inline-start" />
          {isDeleting ? "Deleting..." : "Delete Note"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
