import { useState } from "react";
import type { CommandDefinition, CommandExecutionPayload } from "@shared/contracts";

import { Button } from "@components/UI/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@components/UI/Card";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@components/UI/Dialog";
import { Field, FieldDescription, FieldGroup, FieldLabel } from "@components/UI/Field";
import { Input } from "@components/UI/Input";
import { Textarea } from "@components/UI/Textarea";

interface CreateNoteModalProps {
  command: CommandDefinition;
  isBusy: boolean;
  onCancel: () => void;
  onSubmit: (payload?: CommandExecutionPayload) => void;
  notesRootPath: string;
}

const buildNoteFilename = (title: string) =>
  `${title
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || "note"}.md`;

export function CreateNoteModal({
  command,
  isBusy,
  notesRootPath,
  onCancel,
  onSubmit
}: CreateNoteModalProps) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const filename = buildNoteFilename(title);
  const destinationLabel = notesRootPath.trim() ? `${notesRootPath}\\${filename}` : "Set a notes directory in Settings first.";

  return (
    <DialogContent className="flex max-h-[min(85vh,38rem)] flex-col overflow-hidden p-0 md:max-w-[820px]">
      <DialogHeader>
        <DialogTitle>{command.title}</DialogTitle>
        <DialogDescription>
          {command.subtitle ?? "Save a markdown note in your configured notes directory."}
        </DialogDescription>
      </DialogHeader>
      <div className="flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto px-6 py-5">
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="note-title">Note title</FieldLabel>
            <Input
              autoFocus
              id="note-title"
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Sprint planning notes"
              value={title}
            />
            <FieldDescription>The title becomes the markdown heading and filename.</FieldDescription>
          </Field>
          <Field>
            <FieldLabel htmlFor="note-body">Note body</FieldLabel>
            <Textarea
              className="min-h-[14rem] resize-y"
              id="note-body"
              onChange={(event) => setBody(event.target.value)}
              placeholder={"Capture the actual note here...\n\n- agenda\n- decisions\n- next steps"}
              value={body}
            />
            <FieldDescription>
              Optional. This is saved under the generated `# {title || "title"}` heading.
            </FieldDescription>
          </Field>
        </FieldGroup>
        <Card className="border-border/60 bg-background/40 shadow-none">
          <CardHeader className="gap-2">
            <CardTitle className="text-sm">Destination</CardTitle>
            <CardDescription className="break-all">{destinationLabel}</CardDescription>
          </CardHeader>
          <CardContent className="pt-0 text-sm text-muted-foreground">
            {title.trim()
              ? "A new markdown note will be created at this path."
              : "Enter a title to preview the filename that will be created."}
          </CardContent>
        </Card>
      </div>
      <DialogFooter>
        <Button onClick={onCancel} variant="ghost">
          Cancel
        </Button>
        <Button
          disabled={isBusy || !title.trim()}
          onClick={() => onSubmit({ body, title })}
        >
          {isBusy ? "Creating..." : "Create Note"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
