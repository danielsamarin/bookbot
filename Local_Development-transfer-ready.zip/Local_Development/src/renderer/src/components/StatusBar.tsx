import { Badge } from "@components/UI/Badge";
import { KeyCombo } from "@components/UI/Kbd";
import { Separator } from "@components/UI/Separator";

interface StatusBarProps {
  hotkey: string;
  showApplicationShortcuts?: boolean;
  showNoteDeleteShortcut?: boolean;
  showTemplateRootShortcut?: boolean;
  subtitle?: string;
}

export function StatusBar({
  hotkey,
  showApplicationShortcuts = true,
  showNoteDeleteShortcut,
  showTemplateRootShortcut,
  subtitle
}: StatusBarProps) {
  const hotkeyKeys = hotkey.split("+").map((part) => part.trim()).filter(Boolean);

  return (
    <div className="flex items-center justify-between gap-4 border-t border-border px-4 py-3 text-xs text-muted-foreground">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
        {showApplicationShortcuts ? (
          <>
            <span className="inline-flex items-center gap-2 whitespace-nowrap">
              <span>Run</span>
              <KeyCombo keys={["Enter"]} size="sm" />
            </span>
            <Separator orientation="vertical" className="h-3" />
            <span className="inline-flex items-center gap-2 whitespace-nowrap">
              <span>Hide</span>
              <KeyCombo keys={["Esc"]} size="sm" />
            </span>
            <Separator orientation="vertical" className="h-3" />
            <span className="inline-flex items-center gap-2 whitespace-nowrap">
              <span>Move</span>
              <KeyCombo keys={["↑", "↓"]} size="sm" />
            </span>
            <Separator orientation="vertical" className="h-3" />
          </>
        ) : null}
        {showNoteDeleteShortcut ? (
          <>
            <span className="inline-flex items-center gap-2 whitespace-nowrap">
              <span>Delete</span>
              <KeyCombo keys={["Ctrl", "Delete"]} size="sm" />
            </span>
            <Separator orientation="vertical" className="h-3" />
          </>
        ) : null}
        {showTemplateRootShortcut ? (
          <>
            <span className="inline-flex items-center gap-2 whitespace-nowrap">
              <span>Set template root</span>
              <KeyCombo keys={["Ctrl", "Shift", "R"]} size="sm" />
            </span>
            <Separator orientation="vertical" className="h-3" />
          </>
        ) : null}
        {showApplicationShortcuts ? (
          <span className="inline-flex items-center gap-2 whitespace-nowrap">
            <span>Exit</span>
            <KeyCombo keys={["Ctrl", "Q"]} size="sm" />
          </span>
        ) : null}
      </div>
      <span className="min-w-0 flex-1 truncate text-center">{subtitle ?? "Launcher ready"}</span>
      <Badge className="gap-2" variant="outline">
        <span>Hotkey</span>
        <KeyCombo keys={hotkeyKeys} size="sm" />
      </Badge>
    </div>
  );
}
