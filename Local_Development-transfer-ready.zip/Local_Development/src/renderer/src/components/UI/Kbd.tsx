import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/Utils/Cn";

const kbdVariants = cva(
  "inline-flex min-w-6 items-center justify-center rounded-md border border-border/80 bg-muted/70 px-2 py-0.5 text-[11px] font-medium text-foreground shadow-xs",
  {
    variants: {
      size: {
        default: "h-6",
        sm: "h-5 min-w-5 px-1.5 text-[10px]"
      }
    },
    defaultVariants: {
      size: "default"
    }
  }
);

export interface KbdProps
  extends React.HTMLAttributes<HTMLElement>,
    VariantProps<typeof kbdVariants> {}

export const Kbd = React.forwardRef<HTMLElement, KbdProps>(({ className, size, ...props }, ref) => {
  return (
    <kbd
      ref={ref}
      data-slot="kbd"
      className={cn(kbdVariants({ className, size }))}
      {...props}
    />
  );
});

Kbd.displayName = "Kbd";

const kbdGroupVariants = cva(
  "inline-flex items-center gap-1 rounded-lg border border-border/80 bg-muted/40 p-1 shadow-xs",
  {
    variants: {
      size: {
        default: "min-h-8",
        sm: "min-h-7 gap-1 p-0.5"
      }
    },
    defaultVariants: {
      size: "default"
    }
  }
);

interface KbdGroupProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof kbdGroupVariants> {}

export const KbdGroup = React.forwardRef<HTMLSpanElement, KbdGroupProps>(
  ({ className, size, ...props }, ref) => {
    return (
      <span
        ref={ref}
        data-slot="kbd-group"
        className={cn(kbdGroupVariants({ className, size }))}
        {...props}
      />
    );
  }
);

KbdGroup.displayName = "KbdGroup";

const kbdSeparatorVariants = cva("select-none text-[10px] font-medium text-muted-foreground/80", {
  variants: {
    size: {
      default: "",
      sm: "text-[9px]"
    }
  },
  defaultVariants: {
    size: "default"
  }
});

interface KbdSeparatorProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof kbdSeparatorVariants> {}

export function KbdSeparator({ className, size, ...props }: KbdSeparatorProps) {
  return (
    <span
      aria-hidden="true"
      data-slot="kbd-separator"
      className={cn(kbdSeparatorVariants({ className, size }))}
      {...props}
    >
      +
    </span>
  );
}

interface KeyComboProps extends React.HTMLAttributes<HTMLSpanElement> {
  keys: string[];
  size?: VariantProps<typeof kbdVariants>["size"];
}

export function KeyCombo({ className, keys, size, ...props }: KeyComboProps) {
  const normalizedKeys = keys.filter(Boolean);

  if (normalizedKeys.length <= 1) {
    return (
      <span className={cn("inline-flex items-center", className)} {...props}>
        {normalizedKeys.map((key, index) => (
          <Kbd key={`${size ?? "default"}-${index}-${key}`} size={size}>
            {key}
          </Kbd>
        ))}
      </span>
    );
  }

  return (
    <KbdGroup className={className} size={size} {...props}>
      {normalizedKeys.map((key, index) => (
        <React.Fragment key={`${size ?? "default"}-${index}-${key}`}>
          {index > 0 ? <KbdSeparator size={size} /> : null}
          <Kbd size={size}>{key}</Kbd>
        </React.Fragment>
      ))}
    </KbdGroup>
  );
}
