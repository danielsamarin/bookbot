import type { HTMLAttributes, LabelHTMLAttributes } from "react";

import { cn } from "@/Utils/Cn";

export function FieldGroup({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col gap-4", className)} {...props} />;
}

export function Field({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col gap-2", className)} {...props} />;
}

export function FieldLabel({ className, ...props }: LabelHTMLAttributes<HTMLLabelElement>) {
  return <label className={cn("text-xs font-medium tracking-wide text-muted-foreground uppercase", className)} {...props} />;
}

export function FieldDescription({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("text-sm text-muted-foreground", className)} {...props} />;
}

export function FieldSet({ className, ...props }: HTMLAttributes<HTMLFieldSetElement>) {
  return <fieldset className={cn("flex flex-col gap-3 rounded-xl border border-border bg-muted/20 p-4", className)} {...props} />;
}

export function FieldLegend({ className, ...props }: HTMLAttributes<HTMLLegendElement>) {
  return <legend className={cn("px-1 text-sm font-medium text-foreground", className)} {...props} />;
}
