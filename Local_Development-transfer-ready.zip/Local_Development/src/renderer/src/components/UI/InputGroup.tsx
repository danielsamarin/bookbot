import type { HTMLAttributes } from "react";

import { cn } from "@/Utils/Cn";

export function InputGroup({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex items-center gap-2", className)} {...props} />;
}

export function InputGroupInput({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex-1", className)} {...props} />;
}

export function InputGroupAddon({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("shrink-0", className)} {...props} />;
}
