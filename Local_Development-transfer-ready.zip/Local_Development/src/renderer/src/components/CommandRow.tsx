import type { CommandDefinition } from "@shared/contracts";
import type { Ref } from "react";

import { Badge } from "@components/UI/Badge";
import { CommandItem } from "@components/UI/Command";
import { cn } from "@/Utils/Cn";
import {
  getCommandCategoryLabel,
  getCommandRowLabel,
  renderCommandIcon
} from "@/Utils/CommandPresentation";

interface CommandRowProps {
  command: CommandDefinition;
  index: number;
  isSelected: boolean;
  onHover: (index: number) => void;
  onSelect: (command: CommandDefinition) => void | Promise<void>;
  rowRef?: Ref<HTMLDivElement>;
}

export function CommandRow({
  command,
  index,
  isSelected,
  onHover,
  onSelect,
  rowRef
}: CommandRowProps) {
  return (
    <CommandItem
      ref={rowRef}
      className={cn(
        "mx-2 scroll-mt-12 scroll-mb-4 rounded-xl border border-transparent px-3 py-3",
        isSelected && "border-border/70 bg-accent/80 text-accent-foreground"
      )}
      data-command-index={index}
      onMouseEnter={() => onHover(index)}
      onSelect={() => void onSelect(command)}
      value={command.id}
    >
      <div className="flex size-10 items-center justify-center rounded-xl border border-border bg-background/70 text-foreground">
        {renderCommandIcon(command)}
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-sm font-medium">{command.title}</span>
          <Badge variant="subtle">{getCommandCategoryLabel(command)}</Badge>
        </div>
        <span className="truncate text-sm text-muted-foreground">{command.subtitle ?? "Work Launcher"}</span>
      </div>
      <Badge variant="outline">{getCommandRowLabel(command)}</Badge>
    </CommandItem>
  );
}
