import type { CommandDefinition } from "@shared/contracts";

import type { CommandSection } from "@/Types/Launcher";

const commandSectionCommandIds = new Set([
  "builtin.open-settings",
  "builtin.create-note",
  "builtin.create-folder-structure",
  "builtin.clipboard-actions",
  "builtin.clipboard-history"
]);

export const buildCommandSections = (
  visibleCommands: CommandDefinition[],
  recentCommandIds: string[]
): CommandSection[] => {
  const indexedCommands = visibleCommands.map((command) => ({ command }));
  const recentSet = new Set(recentCommandIds);
  const recentItems = indexedCommands.filter(({ command }) => recentSet.has(command.id));

  recentItems.sort(
    (left, right) => recentCommandIds.indexOf(left.command.id) - recentCommandIds.indexOf(right.command.id)
  );

  const commandItems = indexedCommands.filter(
    ({ command }) => !recentSet.has(command.id) && commandSectionCommandIds.has(command.id)
  );

  const noteItems = indexedCommands.filter(
    ({ command }) =>
      !recentSet.has(command.id) &&
      command.resultType === "note" &&
      !commandSectionCommandIds.has(command.id)
  );

  const shareItems = indexedCommands.filter(
    ({ command }) =>
      !recentSet.has(command.id) &&
      command.resultType === "share" &&
      !commandSectionCommandIds.has(command.id)
  );

  const savedPathItems = indexedCommands.filter(
    ({ command }) =>
      !recentSet.has(command.id) &&
      command.resultType === "saved-path" &&
      !commandSectionCommandIds.has(command.id)
  );

  const extensionItems = indexedCommands.filter(
    ({ command }) =>
      !recentSet.has(command.id) &&
      command.source === "extension" &&
      !commandSectionCommandIds.has(command.id)
  );

  const launchItems = indexedCommands.filter(
    ({ command }) =>
      !recentSet.has(command.id) &&
      !commandSectionCommandIds.has(command.id) &&
      command.resultType !== "note" &&
      command.source !== "extension" &&
      command.resultType !== "share" &&
      command.resultType !== "saved-path"
  );

  const orderedSections = [
    { title: "Recently Used", items: recentItems },
    { title: "Command", items: commandItems },
    { title: "Notes", items: noteItems },
    { title: "Saved Paths", items: savedPathItems },
    { title: "Saved Shares", items: shareItems },
    { title: "Extensions", items: extensionItems },
    { title: "Launch", items: launchItems }
  ].filter((section) => section.items.length > 0);

  let displayIndex = 0;

  return orderedSections.map((section) => ({
    ...section,
    items: section.items.map(({ command }) => ({
      command,
      index: displayIndex++
    }))
  }));
};
