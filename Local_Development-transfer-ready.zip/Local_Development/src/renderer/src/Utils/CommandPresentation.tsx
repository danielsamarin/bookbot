import type { ReactNode } from "react";
import {
  Clipboard,
  Command,
  FolderTree,
  FolderOpen,
  Globe,
  History,
  Monitor,
  NotebookPen,
  Puzzle,
  RefreshCw,
  Server,
  Settings2,
  Sparkles
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import type { CommandDefinition } from "@shared/contracts";

const commandCategoryLabels: Record<string, string> = {
  "builtin.browse-notes": "Notes",
  "builtin.clipboard-actions": "Clipboard",
  "builtin.clipboard-history": "Clipboard",
  "builtin.create-folder-structure": "Workspace",
  "builtin.create-note": "Notes",
  "builtin.launch-chrome": "Browser",
  "builtin.open-settings": "App Settings",
  "builtin.open-windows-settings": "Windows Settings"
};

const commandIcons: Record<string, LucideIcon> = {
  "builtin.browse-notes": NotebookPen,
  "builtin.clipboard-actions": Clipboard,
  "builtin.clipboard-history": History,
  "builtin.create-folder-structure": FolderTree,
  "builtin.create-note": NotebookPen,
  "builtin.launch-chrome": Globe,
  "builtin.open-settings": Settings2,
  "builtin.open-windows-settings": Monitor,
  "builtin.reload-extensions": RefreshCw,
  "hello-world.say-hello": Sparkles
};

const applicationCommandIds = new Set(["builtin.launch-chrome", "builtin.open-windows-settings"]);

export const getCommandCategoryLabel = (command: CommandDefinition) => {
  if (command.resultType === "folder") {
    return "Folder";
  }

  if (command.resultType === "note") {
    return "Note";
  }

  if (command.resultType === "share") {
    return "Network Share";
  }

  if (command.resultType === "saved-path") {
    return "Saved Path";
  }

  return commandCategoryLabels[command.id] ?? (command.source === "extension" ? "Extension" : "Command");
};

export const getCommandRowLabel = (command: CommandDefinition) => {
  if (command.resultType === "folder") {
    return "Tab to Fill";
  }

  if (command.resultType === "note") {
    return "Open";
  }

  if (command.resultType === "share") {
    return "Enter to Fill";
  }

  if (command.resultType === "saved-path") {
    return "Enter to Fill";
  }

  if (applicationCommandIds.has(command.id)) {
    return "Application";
  }

  return command.mode === "view" ? "Command" : "Action";
};

export const renderCommandIcon = (command: CommandDefinition): ReactNode => {
  if (command.iconDataUrl) {
    return <img className="size-5 object-contain" src={command.iconDataUrl} alt="" />;
  }

  if (command.resultType === "folder") {
    return <FolderOpen className="size-4.5" />;
  }

  if (command.resultType === "note") {
    return <NotebookPen className="size-4.5" />;
  }

  if (command.resultType === "share") {
    return <Server className="size-4.5" />;
  }

  if (command.resultType === "saved-path") {
    return <FolderTree className="size-4.5" />;
  }

  const Icon = commandIcons[command.id] ?? (command.source === "extension" ? Puzzle : Command);
  return <Icon className="size-4.5" />;
};
