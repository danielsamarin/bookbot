import type {
  AppSettings,
  ClipboardHistoryEntry,
  CommandDefinition,
  CommandExecutionPayload,
  CommandExecutionResult,
  DevState,
  FolderAutocompleteResult,
  NoteFile,
  NoteSummary
} from "@shared/contracts";

export type ModalType =
  | "create-note"
  | "create-folder"
  | "settings"
  | "extension-prompt"
  | "clipboard-actions"
  | "clipboard-history"
  | "view-note";

export interface ModalCommandState {
  type: ModalType;
  command: CommandDefinition;
}

export interface ViewNoteModalState extends ModalCommandState {
  type: "view-note";
  note: NoteSummary;
}

export type ActiveModal = ModalCommandState | ViewNoteModalState | null;

export interface CommandSectionEntry {
  command: CommandDefinition;
  index: number;
}

export interface CommandSection {
  title: string;
  items: CommandSectionEntry[];
}

export interface WorkLauncherApi {
  listCommands: () => Promise<CommandDefinition[]>;
  executeCommand: (
    commandId: string,
    payload?: CommandExecutionPayload
  ) => Promise<CommandExecutionResult>;
  getSettings: () => Promise<AppSettings>;
  updateSettings: (settings: AppSettings) => Promise<AppSettings>;
  pickDirectory: () => Promise<string | null>;
  getDevState: () => Promise<DevState>;
  hideLauncher: () => Promise<void>;
  quitApp: () => void;
  listNotes: () => Promise<NoteSummary[]>;
  readNote: (notePath: string) => Promise<NoteFile>;
  writeNote: (notePath: string, content: string) => Promise<NoteFile>;
  deleteNote: (notePath: string) => Promise<string>;
  getClipboardText: () => Promise<string>;
  setClipboardText: (text: string) => Promise<void>;
  listClipboardHistory: () => Promise<ClipboardHistoryEntry[]>;
  clearClipboardHistory: () => Promise<void>;
  getFolderSuggestions: (query: string) => Promise<FolderAutocompleteResult | null>;
  openFolder: (folderPath: string) => Promise<CommandExecutionResult>;
  onStateChanged: (callback: () => void) => () => void;
}

declare global {
  interface Window {
    workLauncher: WorkLauncherApi;
  }
}
