import { BridgeFallback } from "@components/BridgeFallback";
import { LauncherResults } from "@components/LauncherResults";
import { DeleteNoteConfirmDialog } from "@components/Modals/DeleteNoteConfirmDialog";
import { ModalHost } from "@components/ModalHost";
import { SearchBar } from "@components/SearchBar";
import { StatusBar } from "@components/StatusBar";
import { Card } from "@components/UI/Card";
import { Command } from "@components/UI/Command";
import { Dialog } from "@components/UI/Dialog";
import { Sonner } from "@components/UI/Sonner";
import { useGlobalLauncherKeys } from "@/Hooks/UseGlobalLauncherKeys";
import { useLauncherState } from "@/Hooks/UseLauncherState";
import { useRootInputKeyDown } from "@/Hooks/UseRootInputKeyDown";

export function App() {
  const {
    activeModal,
    canDeleteSelectedNote,
    cancelDeleteNote,
    closeModal,
    confirmDeleteNote,
    deleteSelectedNote,
    emptyState,
    handleCommandSelection,
    hideLauncher,
    inputRef,
    isBusy,
    isDeletingNote,
    launcherApi,
    navigatedPath,
    openSettings,
    pendingNoteDeletion,
    query,
    requestDeleteNote,
    runCommand,
    sections,
    selectedCommand,
    selectedIndex,
    setQuery,
    setSelectedIndex,
    settings,
    saveSettings,
    saveNavigatedFolderAsTemplateRoot,
    submitSelection,
    tabCompleteSelection,
    visibleCommands
  } = useLauncherState();

  const hideApplicationShortcuts =
    selectedCommand?.resultType === "note" ||
    selectedCommand?.resultType === "saved-path" ||
    selectedCommand?.resultType === "share";

  useGlobalLauncherKeys({
    activeModal,
    canSaveTemplateRootFromPath: Boolean(navigatedPath),
    closeModal,
    openSettings,
    saveTemplateRootFromPath: saveNavigatedFolderAsTemplateRoot,
    quitApp: () => launcherApi?.quitApp()
  });

  const handleRootInputKeyDown = useRootInputKeyDown({
    activeModal,
    hideLauncher,
    onDeleteSelection: deleteSelectedNote,
    onSubmitSelection: submitSelection,
    onTabCompleteSelection: tabCompleteSelection,
    selectedIndex,
    setSelectedIndex,
    visibleCommands
  });

  if (!launcherApi) {
    return <BridgeFallback />;
  }

  return (
    <div className="flex h-full w-full p-1">
      <Card className="flex h-full w-full overflow-hidden rounded-2xl border-white/6 bg-zinc-950/96 shadow-[0_24px_80px_rgba(0,0,0,0.55)]">
        <Command className="h-full" shouldFilter={false}>
          <SearchBar
            inputRef={inputRef}
            onKeyDown={handleRootInputKeyDown}
            onOpenSettings={openSettings}
            onQueryChange={setQuery}
            query={query}
          />
          <LauncherResults
            emptyDescription={emptyState.description}
            emptyTitle={emptyState.title}
            onHover={setSelectedIndex}
            onSelect={handleCommandSelection}
            sections={sections}
            selectedIndex={selectedIndex}
            visibleCommands={visibleCommands}
          />
          <StatusBar
            hotkey={settings.globalHotkey}
            showApplicationShortcuts={!hideApplicationShortcuts}
            showNoteDeleteShortcut={canDeleteSelectedNote}
            showTemplateRootShortcut={Boolean(navigatedPath)}
            subtitle={selectedCommand?.subtitle}
          />
        </Command>
      </Card>
      <ModalHost
        activeModal={activeModal}
        isBusy={isBusy}
        onClose={closeModal}
        onRequestDeleteNote={requestDeleteNote}
        onRunCommand={(payload) => {
          if (activeModal) {
            void runCommand(activeModal.command, payload);
          }
        }}
        onSaveSettings={saveSettings}
        settings={settings}
      />
      <Dialog open={Boolean(pendingNoteDeletion)} onOpenChange={(open) => (!open ? cancelDeleteNote() : undefined)}>
        {pendingNoteDeletion ? (
          <DeleteNoteConfirmDialog
            isDeleting={isDeletingNote}
            note={pendingNoteDeletion}
            onCancel={cancelDeleteNote}
            onConfirm={() => void confirmDeleteNote()}
          />
        ) : null}
      </Dialog>
      <Sonner />
    </div>
  );
}
