import { startTransition, useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

import type {
  AppSettings,
  CommandDefinition,
  CommandExecutionPayload,
  CommandExecutionResult,
  FolderAutocompleteResult,
  NoteSummary
} from "@shared/contracts";

import { useLauncherData } from "@/Hooks/UseLauncherData";
import { getWorkLauncherApi } from "@/Services/LauncherApi";
import { loadRecentCommands, recordRecentCommand, saveRecentCommands } from "@/Services/RecentCommands";
import type { ActiveModal, ModalType } from "@/Types/Launcher";
import { filterCommands } from "@/Utils/CommandSearch";
import { buildCommandSections } from "@/Utils/CommandSections";

const commandViewMap: Record<string, ModalType> = {
  "clipboard-actions": "clipboard-actions",
  "clipboard-history": "clipboard-history",
  "create-note": "create-note",
  "create-folder": "create-folder",
  settings: "settings",
  "extension-prompt": "extension-prompt"
};

const maxRecentCommands = 1;
const uncPathPattern = /^\\\\[^\\]+\\[^\\]+(?:\\.*)?$/;

const normalizeShortcutPath = (value: string) => {
  const trimmedValue = value.trim().replace(/\//g, "\\");
  if (!trimmedValue) {
    return "";
  }

  return trimmedValue.endsWith("\\") ? trimmedValue : `${trimmedValue}\\`;
};

const trimShortcutPath = (value: string) => {
  const normalizedValue = value.trim().replace(/\//g, "\\");
  if (!normalizedValue) {
    return "";
  }

  if (/^[a-zA-Z]:\\$/.test(normalizedValue)) {
    return normalizedValue;
  }

  return normalizedValue.replace(/[\\]+$/, "");
};

export const useLauncherState = () => {
  const launcherApi = getWorkLauncherApi();
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [folderAutocomplete, setFolderAutocomplete] = useState<FolderAutocompleteResult | null>(null);
  const [isBusy, setIsBusy] = useState(false);
  const [isDeletingNote, setIsDeletingNote] = useState(false);
  const [pendingNoteDeletion, setPendingNoteDeletion] = useState<NoteSummary | null>(null);
  const [query, setQuery] = useState("");
  const [recentCommandIds, setRecentCommandIds] = useState<string[]>(loadRecentCommands);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const deferredQuery = useDeferredValue(query);
  const normalizedDeferredQuery = deferredQuery.trim().replace(/\//g, "\\");
  const isFolderQuery =
    /^[a-zA-Z]:\\/.test(normalizedDeferredQuery) ||
    /^[a-zA-Z]:$/.test(normalizedDeferredQuery) ||
    uncPathPattern.test(normalizedDeferredQuery);
  const { commands, notes, refreshState, setSettings, settings } = useLauncherData({ inputRef, launcherApi });

  useEffect(() => inputRef.current?.focus(), [activeModal]);
  useEffect(() => saveRecentCommands(recentCommandIds), [recentCommandIds]);
  useEffect(() => setSelectedIndex(0), [commands, notes, query]);

  useEffect(() => {
    if (!launcherApi) {
      setFolderAutocomplete(null);
      return;
    }

    let isCancelled = false;

    const loadFolderSuggestions = async () => {
      try {
        const nextFolderAutocomplete = await launcherApi.getFolderSuggestions(deferredQuery);
        if (isCancelled) {
          return;
        }

        startTransition(() => {
          setFolderAutocomplete(nextFolderAutocomplete);
        });
      } catch {
        if (isCancelled) {
          return;
        }

        startTransition(() => {
          setFolderAutocomplete(null);
        });
      }
    };

    void loadFolderSuggestions();

    return () => {
      isCancelled = true;
    };
  }, [deferredQuery, launcherApi]);

  const folderCommands = useMemo(
    () =>
      (folderAutocomplete?.suggestions ?? []).map(
        (suggestion): CommandDefinition => ({
          id: `folder:${suggestion.path.toLowerCase()}`,
          title: suggestion.name,
          subtitle: suggestion.path,
          resultType: "folder",
          targetPath: suggestion.path,
          completionPath: suggestion.completionPath,
          source: "builtin",
          mode: "run",
          keywords: [suggestion.path]
        })
      ),
    [folderAutocomplete]
  );

  const shareCommands = useMemo(
    () =>
      settings.networkShares.flatMap((share, index) => {
        const label = share.label.trim();
        const path = share.path.trim().replace(/\//g, "\\");
        if (!label || !path) {
          return [];
        }

        const completionPath = normalizeShortcutPath(path);
        return [
          {
            id: `share:${index}:${path.toLowerCase()}`,
            title: label,
            subtitle: path,
            resultType: "share",
            completionPath,
            source: "builtin",
            mode: "run",
            keywords: [path, label]
          } satisfies CommandDefinition
        ];
      }),
    [settings.networkShares]
  );

  const savedPathCommands = useMemo(
    () =>
      settings.savedWindowsPaths.flatMap((entry, index) => {
        const label = entry.label.trim();
        const path = entry.path.trim().replace(/\//g, "\\");
        if (!label || !path) {
          return [];
        }

        const completionPath = normalizeShortcutPath(path);
        return [
          {
            id: `saved-path:${index}:${path.toLowerCase()}`,
            title: label,
            subtitle: path,
            resultType: "saved-path",
            completionPath,
            source: "builtin",
            mode: "run",
            keywords: [path, label]
          } satisfies CommandDefinition
        ];
      }),
    [settings.savedWindowsPaths]
  );

  const noteCommands = useMemo(
    () =>
      notes.map(
        (note): CommandDefinition => ({
          id: `note:${note.path.toLowerCase()}`,
          title: note.title,
          subtitle: note.name,
          resultType: "note",
          targetPath: note.path,
          source: "builtin",
          mode: "view",
          keywords: [note.name, note.path]
        })
      ),
    [notes]
  );

  const searchableCommands = useMemo(
    () => [...noteCommands, ...savedPathCommands, ...shareCommands, ...commands],
    [commands, noteCommands, savedPathCommands, shareCommands]
  );

  const filteredCommands = useMemo(
    () => (isFolderQuery ? folderCommands : filterCommands(searchableCommands, deferredQuery)),
    [deferredQuery, folderCommands, isFolderQuery, searchableCommands]
  );

  const sections = useMemo(
    () =>
      isFolderQuery
        ? [
            {
              title: "Folders",
              items: folderCommands.map((command, index) => ({
                command,
                index
              }))
            }
          ]
        : buildCommandSections(filteredCommands, recentCommandIds),
    [filteredCommands, folderCommands, isFolderQuery, recentCommandIds]
  );
  const visibleCommands = useMemo(
    () => sections.flatMap((section) => section.items.map(({ command }) => command)),
    [sections]
  );

  const closeModal = () => setActiveModal(null);
  const selectedCommand = visibleCommands[selectedIndex];
  const canDeleteSelectedNote = selectedCommand?.resultType === "note" && Boolean(selectedCommand.targetPath);
  const navigatedPath = useMemo(() => {
    if (isFolderQuery && folderAutocomplete?.exactPath) {
      return folderAutocomplete.exactPath;
    }

    if (selectedCommand?.resultType === "folder" && selectedCommand.targetPath) {
      return selectedCommand.targetPath;
    }

    if (
      (selectedCommand?.resultType === "share" || selectedCommand?.resultType === "saved-path") &&
      selectedCommand.completionPath
    ) {
      return trimShortcutPath(selectedCommand.completionPath);
    }

    return null;
  }, [folderAutocomplete, isFolderQuery, selectedCommand]);

  const hideLauncher = async () => {
    setActiveModal(null);
    setQuery("");
    await launcherApi?.hideLauncher();
  };

  const handleExecutionResult = async (
    result: CommandExecutionResult,
    options: { refresh?: boolean } = {}
  ) => {
    if (!result.ok) {
      toast.error(result.title ?? "Command Failed", { description: result.message });
      return;
    }

    toast.success(result.title ?? "Success", { description: result.message });
    if (options.refresh !== false) {
      await refreshState();
    }

    if (settings.autoMinimizeAfterAction) {
      await hideLauncher();
      return;
    }

    closeModal();
  };

  const runCommand = async (command: CommandDefinition, payload: CommandExecutionPayload = {}) => {
    if (!launcherApi) {
      toast.error("Desktop Bridge Missing", {
        description: "Restart the Electron app to reload the preload script."
      });
      return;
    }

    setIsBusy(true);
    try {
      const result = await launcherApi.executeCommand(command.id, payload);
      await handleExecutionResult(result);
    } finally {
      setIsBusy(false);
    }
  };

  const openFolder = async (folderPath: string) => {
    if (!launcherApi) {
      toast.error("Desktop Bridge Missing", {
        description: "Restart the Electron app to reload the preload script."
      });
      return;
    }

    setIsBusy(true);
    try {
      const result = await launcherApi.openFolder(folderPath);
      await handleExecutionResult(result, { refresh: false });
    } finally {
      setIsBusy(false);
    }
  };

  const recordUsage = (commandId: string) => {
    setRecentCommandIds((current) => recordRecentCommand(commandId, current, maxRecentCommands));
  };

  const openSettings = () => {
    const settingsCommand = commands.find((command) => command.id === "builtin.open-settings");
    if (!settingsCommand) {
      return;
    }

    recordUsage(settingsCommand.id);
    setActiveModal({ type: "settings", command: settingsCommand });
  };

  const handleCommandSelection = async (command: CommandDefinition) => {
    if ((command.resultType === "share" || command.resultType === "saved-path") && command.completionPath) {
      recordUsage(command.id);
      setQuery(command.completionPath);
      return;
    }

    if (command.resultType === "note" && command.targetPath) {
      const note = notes.find((entry) => entry.path === command.targetPath);
      if (!note) {
        toast.error("Note Not Found", {
          description: "Refresh the launcher and try again."
        });
        return;
      }

      recordUsage(command.id);
      setActiveModal({ type: "view-note", command, note });
      return;
    }

    if (command.resultType === "folder" && command.targetPath) {
      await openFolder(command.targetPath);
      return;
    }

    recordUsage(command.id);
    if (command.mode === "run") {
      await runCommand(command);
      return;
    }

    const modalType = command.viewId ? commandViewMap[command.viewId] : undefined;
    if (!modalType) {
      toast.error("Unsupported View", { description: command.title });
      return;
    }

    setActiveModal({ type: modalType, command });
  };

  const saveSettings = async (nextSettings: AppSettings) => {
    if (!launcherApi) {
      return;
    }

    setIsBusy(true);
    try {
      const savedSettings = await launcherApi.updateSettings(nextSettings);
      setSettings(savedSettings);
      toast.success("Settings Saved", { description: "Your launcher preferences were updated." });
      closeModal();
    } finally {
      setIsBusy(false);
    }
  };

  const saveNavigatedFolderAsTemplateRoot = async () => {
    if (!launcherApi || !navigatedPath) {
      return;
    }

    setIsBusy(true);
    try {
      const savedSettings = await launcherApi.updateSettings({
        ...settings,
        folderTemplateRootPath: navigatedPath
      });
      setSettings(savedSettings);
      toast.success("Folder Template Root Updated", {
        description: navigatedPath
      });
    } finally {
      setIsBusy(false);
    }
  };

  const deleteSelectedNote = async () => {
    if (!selectedCommand?.targetPath || selectedCommand.resultType !== "note") {
      return;
    }

    const note = notes.find((entry) => entry.path === selectedCommand.targetPath);
    if (!note) {
      toast.error("Note Not Found", {
        description: "Refresh the launcher and try again."
      });
      return;
    }

    setPendingNoteDeletion(note);
  };

  const requestDeleteNote = (note: NoteSummary) => {
    setPendingNoteDeletion(note);
  };

  const cancelDeleteNote = () => {
    if (isDeletingNote) {
      return;
    }

    setPendingNoteDeletion(null);
  };

  const confirmDeleteNote = async () => {
    if (!launcherApi || !pendingNoteDeletion) {
      return;
    }

    if (typeof launcherApi.deleteNote !== "function") {
      toast.error("Desktop Bridge Missing", {
        description: "Restart the Electron app to reload the desktop bridge."
      });
      return;
    }

    setIsDeletingNote(true);
    try {
      await launcherApi.deleteNote(pendingNoteDeletion.path);
      toast.success("Note Deleted", { description: pendingNoteDeletion.title });
      if (
        activeModal?.type === "view-note" &&
        "note" in activeModal &&
        activeModal.note.path === pendingNoteDeletion.path
      ) {
        closeModal();
      }
      setPendingNoteDeletion(null);
      await refreshState();
      if (settings.autoMinimizeAfterAction) {
        await hideLauncher();
      }
    } catch (deleteError) {
      toast.error("Delete Failed", {
          description: deleteError instanceof Error ? deleteError.message : String(deleteError)
      });
    } finally {
      setIsDeletingNote(false);
    }
  };

  const submitSelection = async () => {
    if (isFolderQuery && folderAutocomplete?.exactPath) {
      await openFolder(folderAutocomplete.exactPath);
      return;
    }

    const selectedCommand = visibleCommands[selectedIndex];
    if (selectedCommand) {
      await handleCommandSelection(selectedCommand);
    }
  };

  const tabCompleteSelection = () => {
    const selectedCommand = visibleCommands[selectedIndex];
    if (selectedCommand?.resultType !== "folder" || !selectedCommand.completionPath) {
      return;
    }

    setQuery(selectedCommand.completionPath);
  };

  const emptyState = useMemo(() => {
    if (isFolderQuery) {
      return folderAutocomplete?.exactPath
        ? {
            title: "No child folders matched",
            description: "Press Enter to open the current folder, or keep typing to narrow the next segment."
          }
        : {
            title: "No folder matched",
            description: "Keep typing an absolute Windows path such as C:\\Users\\."
          };
    }

    return {
      title: "No command matched",
      description: "Try Create Note or open Settings to configure your paths."
    };
  }, [folderAutocomplete, isFolderQuery]);

  return {
    activeModal,
    canDeleteSelectedNote,
    cancelDeleteNote,
    closeModal,
    confirmDeleteNote,
    deleteSelectedNote,
    emptyState,
    handleCommandSelection,
    hideLauncher,
    inputRef,
    isBusy,
    isDeletingNote,
    launcherApi,
    openSettings,
    pendingNoteDeletion,
    navigatedPath,
    query,
    requestDeleteNote,
    runCommand,
    sections,
    selectedCommand,
    selectedIndex,
    setQuery,
    setSelectedIndex,
    settings,
    saveSettings,
    saveNavigatedFolderAsTemplateRoot,
    submitSelection,
    tabCompleteSelection,
    visibleCommands
  };
};
