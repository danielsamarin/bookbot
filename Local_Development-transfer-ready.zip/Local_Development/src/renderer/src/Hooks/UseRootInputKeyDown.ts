import type { KeyboardEvent } from "react";

import type { CommandDefinition } from "@shared/contracts";

import type { ActiveModal } from "@/Types/Launcher";

interface UseRootInputKeyDownOptions {
  activeModal: ActiveModal;
  hideLauncher: () => Promise<void>;
  onDeleteSelection: () => Promise<void>;
  onSubmitSelection: () => Promise<void>;
  onTabCompleteSelection: () => void;
  selectedIndex: number;
  setSelectedIndex: (value: number | ((current: number) => number)) => void;
  visibleCommands: CommandDefinition[];
}

export const useRootInputKeyDown = ({
  activeModal,
  hideLauncher,
  onDeleteSelection,
  onSubmitSelection,
  onTabCompleteSelection,
  selectedIndex,
  setSelectedIndex,
  visibleCommands
}: UseRootInputKeyDownOptions) => {
  return async (event: KeyboardEvent<HTMLInputElement>) => {
    if (activeModal) {
      return;
    }

    if (event.key === "ArrowDown") {
      event.preventDefault();
      setSelectedIndex((current) => Math.min(current + 1, Math.max(visibleCommands.length - 1, 0)));
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      setSelectedIndex((current) => Math.max(current - 1, 0));
    }

    if (event.key === "Enter") {
      event.preventDefault();
      await onSubmitSelection();
    }

    if (event.ctrlKey && event.key === "Delete") {
      const selectedCommand = visibleCommands[selectedIndex];
      if (selectedCommand?.resultType === "note") {
        event.preventDefault();
        await onDeleteSelection();
      }
    }

    if (event.key === "Tab") {
      const selectedCommand = visibleCommands[selectedIndex];
      if (selectedCommand?.resultType === "folder") {
        event.preventDefault();
        onTabCompleteSelection();
      }
    }

    if (event.key === "Escape") {
      event.preventDefault();
      await hideLauncher();
    }
  };
};
