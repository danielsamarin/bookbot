import { useEffect } from "react";

import type { ActiveModal } from "@/Types/Launcher";

interface UseGlobalLauncherKeysOptions {
  activeModal: ActiveModal;
  canSaveTemplateRootFromPath: boolean;
  closeModal: () => void;
  saveTemplateRootFromPath: () => Promise<void>;
  openSettings: () => void;
  quitApp: () => void;
}

export const useGlobalLauncherKeys = ({
  activeModal,
  canSaveTemplateRootFromPath,
  closeModal,
  saveTemplateRootFromPath,
  openSettings,
  quitApp
}: UseGlobalLauncherKeysOptions) => {
  useEffect(() => {
    const handleGlobalKeys = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.shiftKey && event.key.toLowerCase() === "r") {
        if (activeModal || !canSaveTemplateRootFromPath) {
          return;
        }

        event.preventDefault();
        void saveTemplateRootFromPath();
        return;
      }

      if (event.ctrlKey && event.key.toLowerCase() === "s") {
        event.preventDefault();

        if (activeModal) {
          if (activeModal.type === "settings") {
            closeModal();
          }
          return;
        }

        openSettings();
        return;
      }

      if (event.ctrlKey && event.key.toLowerCase() === "q") {
        event.preventDefault();
        quitApp();
        return;
      }

      if (event.key === "Escape" && activeModal) {
        event.preventDefault();
        closeModal();
        return;
      }

      return;
    };

    window.addEventListener("keydown", handleGlobalKeys, true);
    return () => window.removeEventListener("keydown", handleGlobalKeys, true);
  }, [
    activeModal,
    canSaveTemplateRootFromPath,
    closeModal,
    openSettings,
    quitApp,
    saveTemplateRootFromPath
  ]);
};
